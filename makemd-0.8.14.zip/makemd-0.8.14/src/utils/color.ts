export const colors = [
  ["Red", "#eb3b5a"],
  ["Orange", "#fa8231"],
  ["Yellow", "#f7b731"],
  ["Green", "#20bf6b"],
  ["Turquoise", "#0fb9b1"],
  ["Teal", "#2d98da"],
  ["Blue", "#3867d6"],
  ["Purple", "#8854d0"],
  ["Charcoal", "#4b6584"],
];
