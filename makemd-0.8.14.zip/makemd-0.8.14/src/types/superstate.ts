export type WorkerJobType = {
    type: string,
    path: string,
}